frontend-nanodegree-arcade-game
===============================

Students should use this [rubric](https://review.udacity.com/#!/projects/2696458597/rubric) for self-checking their submission. Make sure the functions you write are **object-oriented** - either class functions (like Player and Enemy) or class prototype functions such as Enemy.prototype.checkCollisions, and that the keyword 'this' is used appropriately within your class and class prototype functions to refer to the object the function is called upon. Also be sure that the **readme.md** file is updated with your instructions on both how to 1. Run and 2. Play your arcade game.

•INTRODUCTION
The name of the game is FROGGER and its 3rd project in FRONT END NANODEGREE from UDACITY.this game is buils using object oriented concepts of javascript programming

•HOW TO PLAY:
This is a simple game but requires some talent and concentration..
Use up , down , left , right keys to move your player up ,down ,left , rigt respectively.
Prevent your collision with the enemy bugs and try to safely reach the water and a score of one woll add to your score.

•SETUP:
To operate this game download this folder to your PC directory.
Extract the files and open the index.html file in any browser
The game will load and thats it!!
HAVE FUN!!

For detailed instructions on how to get started, check out this [guide](https://docs.google.com/document/d/1v01aScPjSWCCWQLIpFqvg3-vXLH2e8_SZQKC8jNO0Dc/pub?embedded=true).
